ALTER TABLE `lists` 
 DROP COLUMN `user`
 ADD COLUMN `rtable` VARCHAR(45) NOT NULL,
 ADD COLUMN `email` VARCHAR(45) AFTER `rtable`,
 ADD COLUMN `forename` VARCHAR(45) AFTER `email`,
 ADD COLUMN `surname` VARCHAR(45) AFTER `forename`,
 ADD COLUMN `business` VARCHAR(45) AFTER `surname`,
 ADD COLUMN `user1` VARCHAR(45) AFTER `business`,
 ADD COLUMN `user2` VARCHAR(45) AFTER `user1`,
 ADD COLUMN `fcol` VARCHAR(45) AFTER `user2`,
 ADD COLUMN `fop` VARCHAR(6) AFTER `fcol`,
 ADD COLUMN `fval` VARCHAR(45) AFTER `fop`;

ALTER TABLE `mailqueue` 
ADD COLUMN `list` VARCHAR(45) NOT NULL AFTER `messageid`;

CREATE TABLE `mailsystem` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `nexttable` INTEGER UNSIGNED,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB;

CREATE TABLE `mailusers` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`)
)
ENGINE = InnoDB;
