<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	SendNews.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Control send of newsletters
//	Parameters	id of message
// --------------------------------------------------------------
/*
function showMessageList()
function showRecord($record)
function showManager($id)
function formatSQLDate($dt)
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Email Send Newsletter</title>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<link rel="stylesheet" type="text/css" href="../../includes/Menus.css">
</head>

<body style='background-color: #eeeeee;'>
<?php
	include "LogCheck.php";

	$msgId = $_GET['id'];
	$sql = "SELECT * FROM mailmessages WHERE id=$msgId";
	$result = mysqli_query($dbConnection, $sql)
		or die("Error: $sql");
	$record = mysqli_fetch_array($result);

	mysqli_free_result($result);
	
//	echo $sql;
	$head = $record['name'];
	$prompt = "Select the list to send the message to";

	echo "<h1>Mailer: Send Newsletter</h1>";
	echo "<h3>$head</h3>";

	echo "<button onClick='home()'>Home</button>";

								// Panel for recipient list preview
	echo "<div style='position: absolute; left:50px; top:150px'>";
		echo "<span >$prompt</span>";
		echo "<br><br>";
		showList();
	echo "</div>";
	echo "<div style='position: absolute; left:50px; top:500px'>";
		showForm($record);
	echo "</div>";
	echo "<div id='listpreview'>";
	echo "<button type='button' onClick='closePreview()'>Close</button>"; 
	echo "</div>";

// ----------------------------------------------
//	Show the form
//	
//	Parameter	message record
// ----------------------------------------------
function showForm($record)
{
	echo "<br>";
	$subject = $record['subject'];
	$from = $record['sender'];
	$msgId = $_GET['id'];
	$id2 = '';
	$rtable = '';

	echo "<form onSubmit='return checkForm()' action='GenerateNews.php' method='post'>";
		echo "<span class='prompt1'>Subject</span>";
		echo "<span class='input1'><input type='text' name='subject' id='msSubject' value='$subject'></span>";
		echo "<br><br>";
		echo "<span class='prompt1'>Sender</span>";
		echo "<span class='input1'><input type='text' name='from' id='msFrom' value='$from'></span>";
		echo "<br><br>";
		echo "<span class='prompt1'><input type='submit' value=' Send '></span><br>";
		echo "<input type='hidden' id='msmode' name='mode' value='list'>";
		echo "<input type='hidden' id='msmsgid' name='msgid' value='$msgId'>";
		echo "<input type='hidden' id='rcid' name='rcid' value='$id2'>";
		echo "<input type='hidden' id='table' name='table'>";
	echo "</form>";

}

// ----------------------------------------------
//	Show the recipient lists (Preview)
//
// ----------------------------------------------
function showList()
{
	global $dbConnection;

	echo "\n<div class='selector' style='width:400px; padding-left:5px'>";
			$sql = "SELECT * FROM maillists ORDER BY id DESC";
		$result = mysqli_query($dbConnection, $sql);
		while ($record = mysqli_fetch_array($result))
			showRecord($record);
	echo "</div>";
}

// ----------------------------------------------
//	Show the mail list record
//
// ----------------------------------------------
function showRecord($record)
{
	$id = $record['id'];
	$name = 'sr' . $id;

	echo "<span style='position:absolute; width: 300px' id='$name' "
		. "onClick='msmSelect(\"$id\", $id)'>";
	$name = $record['name'];
	echo $record['name'];
	echo "</span>";
//	echo "<span style='position:absolute; left:400px'  onClick='previewList2(\"$id\")'>";
//		echo "Preview</span>";
	echo "<br>\n";
}

?>
<script>
// ----------------------------------------
//	Handler for list selection 
//
//	Set the hidden form fields to allow
//	post of the recipient
// ----------------------------------------
function msmSelect(table, id)
{
	if (selList != 0)			// Remove existing highlight
	{
		var span = 'sr' + selList;
		var el = document.getElementById(span);
		el.style.fontWeight = 'normal';
	}

	selList = id;
	var el = document.getElementById('rcid');
	el.value = id;
	el = document.getElementById('table');
	el.value = table;
	var span = 'sr' + id;
	var el = document.getElementById(span);
	el.style.fontWeight = 'bold';
	
	previewList2(id);
}

function checkForm()
{
	var el = document.getElementById('rcid');
	if (el.value == '')
	{
		alert('You must select a list');
		return false;
	}
	return true;
}

</script>

</body>
</html>
