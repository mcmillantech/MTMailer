<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	BasicMail.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
// Compose and send a messages
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Write a basic email</title>
	<meta charset="utf-8">
<?php
	$ckpath = getenv('CKPATH');
	if ($ckpath=='')
		$ckpath = "../ckeditor/ckeditor.js";
	echo "<script src='$ckpath'></script>";
?>
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<style>
	</style>
</head>

<body >
<h1>Mailer: Write Email</h1>
<button onClick='home()'>Home</button>
<?php

	echo "<div id='container'>";
	showForm();
	echo "<div id='listpreview'>";		// This holds the (hidden) CKEditor pane
	echo "<button type='button' onClick='closePreview()'>Close</button>"; 
	echo "</div>";
	echo "<br>";
	echo "</div>";

// ---------------------------------------
//	The Form
// ---------------------------------------
function showForm()
{
	global $dbConnection;

	echo "<div class='basicmailform'>";
	echo "<form id='bmForm' action='BasicMail2.php' method='post'>";

	echo "<span class='prompt1'>Sender address</span>";
	echo "<span class='input1'><input type='text' id='mcFrom' name='sender' size='45'></span>";
	echo "<br><br>";

	echo "<span class='prompt1'>Message name</span>";
	echo "<span class='input1'><input type='text' id='mcName' name='name' size='45' value='Basic mail'></span>";
	echo "<br>&nbsp;&nbsp;(For your reference)<br>";

	echo "\n<span class='prompt1'>Recipients</span>";			// Hidden recipient name
	echo "<span class='input1' id=bmtoone style='visibility:hidden'>";
	echo "<input type='text' id='bmToOne' name='bmOne' size='40'>";
	echo "</span>";
	echo "<span class='input1' id=bmtolist name='bmList'>";
	showRecipientList();
	echo "&nbsp;&nbsp;";
	echo "<button type='button' onClick='previewList()'>Preview</button>";
	echo "</span>";
					// Radio buttons for list or single
	echo "\n<span style='position: absolute; left:500px'>";
	echo "<input type='radio' name='bmto' value='List'  checked onChange='bmRadio(1)'>Send to a list ";
	echo "<input type='radio' name='bmto' value='Single' onChange='bmRadio(2)'> Send to one";
	echo "</span>";
	echo "<br><br>";

	echo "<span class='prompt1'>Subject</span>";
	echo "<span class='input1'><input type='text' id='subject' name='subject' size='45'></span>";
	echo "<br><br>";

	echo "<textarea name='htmltext' id='editTA' rows='25' cols='60'>Dear {forename}</textarea>";
	echo "<script>";
	echo "  CKEDITOR.replace( 'htmltext' );";
	echo "  </script>";

	echo "<br><br>";
	echo "<button onClick='bmSend()' name='btnSend'>Send</button>";
	echo "&nbsp;&nbsp;&nbsp;";
	echo "<button onClick='bmSend()' name='btnSave'>Save</button>";
	echo "</form></div>";
}

// -------------------------------------------
//	Build and show recipient lists drop down 
//
// -------------------------------------------
function showRecipientList()
{
	include "LogCheck.php";

	echo "<select id='bmToList' name='rlist' style='width:100px'>";
	$sql = "SELECT * FROM maillists";
	$result = mysqli_query($dbConnection, $sql)
		or die ("Error : $sql");
	while ($record = mysqli_fetch_array($result))
	{
		$name = $record['name'];
//		$rtable = $record['rtable'];
		$list = $record['id'];
//		echo "<option value='$list'>$list</option>";
		echo "<option value='$list'>$name</option>";
	}
	echo "</select>";
}
?>
<script>
// ---------------------------------------
//	Handler for radio buttons
//
// ---------------------------------------
function bmRadio(which)
{
	switch (which)
	{
	case 1:
		var el = document.getElementById('bmtoone');
		el.style.visibility = 'hidden';
		el = document.getElementById('bmtolist');
		el.style.visibility = 'visible';
		break;
	case 2:
		var el = document.getElementById('bmtolist');
		el.style.visibility = 'hidden';
		el = document.getElementById('bmtoone');
		el.style.visibility = 'visible';
		break;
	}
}

function bmSend()
{
	document.getElementById("bmForm").submit();
}

function home()
{
	document.location.assign('Home.php');
}

</script>
</body>
</html>
