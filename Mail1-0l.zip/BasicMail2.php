<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	BasicMail2.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Send a basic message
//	Evoked from Send and Save buttons in BasicMail
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Write a basic email</title>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
<script>
// Handler for Home button
function home()
{
	document.location.assign('Home.php');
}

</script>
</head>
<body >
<?php
	include "LogCheck.php";
	include "MTMail.php";

	$name = $_POST['name'];					// Fetch data from BasicMail.php
	$subject = $_POST['subject'];
	$sender = $_POST['sender'];
	$htmltext = $_POST['htmltext'];
	date_default_timezone_set("Europe/London");	// Today's date
	$dtSQL = date('Y-m-d G:i:s');
												// Save the message
/*	$sql = "INSERT INTO sentmessages (name, subject, sender, created, htmltext) "
		. "VALUES ('$name', '$subject', '$sender', '$dtSQL', '" 
		. addslashes($htmltext) . "')";

	mysqli_query($dbConnection, $sql)
		or die ("SQL error " . mysqli_error($dbConnection) . $sql);
	$msgId = $dbConnection->insert_id;		// Get the id of the new message
*/
//	echo "<br>$msgId<br>";
											// Save button was clicked - we're done
	if (array_key_exists('btnSave', $_POST))
	{
		echo "Message $name saved<br><br>";
		echo "<button onClick='home()'>Return to home</button>";
		return;
	}

											// Send button was clicked
	$mailer = new MTmail($dbConnection);
	$mailer->setMessage(0, $htmltext);
	$mailer->sender($sender);
	$mailer->subject($subject);
	$mailer->messageName($name);

	$which = $_POST['bmto'];
	if ($which == 'Single')					// Send to one
		$mailer->sendByAddress($_POST['bmOne']);
	else
		$mailer->sendList($_POST['rlist']);

//	echo "Message $name sent<br><br>";
	echo "<br><br><button onClick='home()'>Return to home</button>";
?>

</body>
</html>
