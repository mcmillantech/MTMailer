<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	CronMail.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//	Send queued messages
// --------------------------------------------------------------

	$hfile = fopen('config.txt', 'r');
	if (!$hfile)
		die ("Could not open config file");
	$config = array();

	while (!feof($hfile))		// config.txt holds DB name, password and user
	{
		$str = fgets($hfile);
		sscanf($str, '%s %s', $ky, $val);
		$config[$ky] = $val;
	}
	fclose ($hfile);

	$dbConnection = mysqli_connect ('localhost', $config['dbuser'], $config['dbpw'])
		or die("Could not connect : " . mysqli_connect_error());

	mysqli_select_db($dbConnection, $config['dbname']) 
		or die("Could not select database : " . mysqli_error($dbConnection));

	include "MTMail.php";			// Mailer class
	$batchSize = 8;
									// Fetch the oldest incomplete record from the queue table
	$sql = "SELECT * FROM mailqueue WHERE status != 'complete'";
	$result = mysqli_query($dbConnection, $sql);
	if (mysqli_num_rows($result) == 0)					// Nothing in the queue
		exit;

	$queue = mysqli_fetch_array($result);

	$stats = sendMails($queue);
	print_r($stats);
	endOfRun($queue, $stats);

	mysqli_free_result($result);

// ----------------------------------------------------
//	This is the workhorse
//
//	Use an MTmail object to build and send the message
//
//	Parameter	queue table record
// ----------------------------------------------------
function sendMails($queue)
{
	global $dbConnection, $batchSize;

	$msg = $queue['messageid'];
	$mailer = new MTmail($dbConnection);

	$stats = array				// Data to be posted at the end of run
	(
		'nStart' => 0,
		'nSent' => 0,
		'emStart' => '',
		'emEnd' => ''
	);

	$count = 0;

	$html = $queue['html'];		// Distribute the data for the email
	$row = $queue['lastrow'];
	$list = $queue['listid'];
	$subject = $queue['subject'];
	$table = $queue['list'];
	$mailer->setMessage($msg, $html);
	$mailer->setList($queue);

	$params['sendmail_path'] = '/usr/lib/sendmail';

	$mailer->setQueueData($html, $subject);

	if ($_SERVER['SERVER_NAME'] != 'localhost')			// i.e. this is the production server
	{
		$pearMail =& Mail::factory('sendmail', $params);
		$mailer->setPearMail($pearMail);
	}
									// Read the next batch of addresses from the queue
	$sql = makeListSQL($mailer->lst(), $row);

	$resultr = mysqli_query($dbConnection, $sql)
		or die("Error reading queue " . $sql);
	while ($recip = mysqli_fetch_array($resultr))
	{
		$recip = $mailer->setMap($recip);

		if ($count == 0)
		{
			$stats['nStart'] = $queue['lastrow'];
			$stats['emStart'] = $recip['email'];	// Map!
		}
		$mailer->sendQueued($recip);
		$count++;
		$stats['emEnd'] = $recip['email'];	// Map!
		$stats['nSent'] = $count;
	}
	return $stats;

	mysqli_free_result($resultr);
}

function makeListSQL($dta, $row)
{
	global $batchSize;

	$table = $dta['rtable'];
	if ($dta['fcol'] == '')				// Build the filter
		$where = '';
	else
	{
		$where = " WHERE " . $dta['fcol'] . $dta['fop'] . "'" . $dta['fval'] . "'";
	}
	$sql = "SELECT * FROM $table $where LIMIT $batchSize OFFSET $row";

	return $sql;
}

// ----------------------------------------------------
//	End of run
//	Update the queue and list table
//	Write the log file
//
//	Parameters	Queue record
//				Array of data
// ----------------------------------------------------
function endOfRun($queue, $stats)
{
	global $dbConnection, $batchSize;

	$endOfJob = false;
	$status = 'sending';
	$nSent = $stats['nSent'];

	if ($nSent < $batchSize)				// Test for end of this job
	{
		$endOfJob = true;
		$nSent = true;
		$status = 'complete';
	}
	
	$nEnd = $stats['nStart'] + $nSent;			// Update the queue table
	$inx = $queue['inx'];
	$totalSent = $queue['totalsent'] + $nSent;
	date_default_timezone_set("Europe/London");
	
	$sDate = date('d-m-Y');
	$sqlQ = "UPDATE mailqueue SET status='$status', totalsent=$totalSent";
	if (!$endOfJob)
		$sqlQ .= ", lastrow=$nEnd";
	$sqlQ .= " WHERE inx=$inx";
	mysqli_query($dbConnection, $sqlQ);
//	echo $sqlQ;

	if ($endOfJob)								// When job finished, update the list table
	{
	echo "----------<br>End of Job<br>";
//	print_r($queue);
		$list = $queue['listid'];
		$sqlL = "UPDATE maillists SET nSent=$totalSent, lastSend='$sDate' WHERE id=$list";
		mysqli_query($dbConnection, $sqlL);
	}
	
	date_default_timezone_set("Europe/London");	// Write log file
	$sDate = date('d-m-Y G:i');

	$hFile = fopen('sendlog.txt', 'a');			// Finally write to the log file
	fprintf($hFile, "%16s %8s %3d %20s %3d %s\r\n",
		$sDate, $queue['list'], $stats['nStart'], $stats['emStart'], $nEnd, $stats['emEnd']);
	fclose ($hFile);
}

?>
