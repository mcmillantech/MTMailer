<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	Home.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Home page 
// --------------------------------------------------------------
	require_once "LogCheck.php";
?>

<!DOCTYPE html>
<html>
<head>
<title>Email Messages</title>
	<meta charset="utf-8">
<!--	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css"> -->
	<style>
	.whatpanel
	{
		position:	absolute;
		width:		350px;
		background-color:	white;
		left:		200px;
		min-height:	30px;
		border:		1px solid;
		padding-top:	5px;
	}
	.whattext
	{
		font-family: arial, sans-serif;
		font-size: 120%;
		text-align: center;
	}
	button
	{
		margin-left:	10px;
		margin-top:		10px;
		margin-bottom:	10px;
		font-size:		16px;
	}
	</style>
</head>

<body style='background-color: #eeeeee;'>
<h1 style='margin-left:250px'>Mailer: Messages</h1>
<div style='position:absolute' id='container'>
	<div class='whatpanel' style='top:50px'>
		<div class='whattext'>What do you want to do?</div>
	</div>
	<br><br>
	<div class='whatpanel' style='top:130px'>
	<?php
		showMenu();
		?>
		<br>
		<button onClick='logOut()'>Log out</button>
	</div>
</div>

<?php
function showMenu()
{
	$level = $_SESSION['userLevel'];
	$items = array
	(
		array("Write and send a basic email", "doBasic()", 1),
		array("Compose and send a newsletter", "doCompose()", 2),
		array("See emails that have been sent", "viewSend()", 2),
		array("Manage subscribers", "doLists()", 2),
		array("Manage email layouts", "templates()", 3)
	);
	
	for ($i=0; $i<count($items); $i++)
	{
		echo "<button onClick='" . $items[$i][1] . "'";
		if ($items[$i][2] > $level)
			echo " disabled";
		echo ">" . $items[$i][0] . "</button>";
	}
}

?>
<script>
function doBasic()
{
	window.location.assign("BasicMail.php");
}

function doCompose()
{
	window.location.assign("Newsletters.php");
}

function doLists()
{
	window.location.assign("MailLists.php");
}

function logOut()
{
	window.location.assign("LogOut.php");
}

function templates()
{
	window.location.assign("Templates.php");
}

function viewSend()
{
	window.location.assign("ViewLog.php");
}

function none()
{
	alert('Not available');
}

</script>
</body>
</html>
