<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	MlView.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Present and manage a mailing list 
// --------------------------------------------------------------
/*
function makeManageMenu()
function heading()
function showList($rtable)
function showManager($id)
*/
			// Check user is logged on
	require_once "LogCheck.php";
?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<style>
		.mll0
		{
		  position: absolute;
		  left: 5px;
		  width: 250px;
		}
		.mll1
		{
		  position: absolute;
		  left: 255px;
		  width: 100px;
		}
		.mll2
		{
		  position: absolute;
		  left: 355px;
		  width: 100px;
		}
		.mll3
		{
		  position: absolute;
		  left:	 455px;
		  width: 140px;
		}
		.mll4
		{
		  position: absolute;
		  left: 615px;
		  width: 300px;
		}
	</style>
<?php
// --------------- This is the <head> section ---------------------

//	$rtable = $_GET['lst'];			// Fetch the table name
//	$sql = "SELECT * FROM maillists WHERE rtable='$rtable'";
	$list = $_GET['lst'];			// Fetch the table name
	$sql = "SELECT * FROM maillists WHERE name='$list'";
	$result = mysqli_query($dbConnection, $sql)
		or die ("Error : $sql");
	$lstRecord = mysqli_fetch_array($result);
	
	$listName = $lstRecord['name'];
	
	$colMap = array(					// Make array of custom column names
		'ky' => makeCol($lstRecord, 'ky'),
		'email' => makeCol($lstRecord, 'email'),
		'forename' => makeCol($lstRecord, 'forename'),
		'surname' => makeCol($lstRecord, 'surname'),
		'business' => makeCol($lstRecord, 'business')
	);
	
	$filter = makeFilter($lstRecord);
//	echo $filter;

	mysqli_free_result($result);

	echo "<title>Email list: $listName</title>";

// ----------------------------------------------
//	Make the columns mapping record
//
// ----------------------------------------------
function makeCol($record, $col)
{
	$c = $record[$col];
	if ($c == '')				// No entry - use the default
	{
		if ($col == 'ky')		// Default to the column name except for id
			$c = 'id';
		else
			$c = $col;
	}

	return $c;
}

function makeFilter($record)
{
	$fcol = $record['fcol'];
	if ($fcol == '')
		return '';
	$filter = " WHERE $fcol "
		. $record['fop']
		. $record['fval'];
//		. " '" . $record['fval'] . "'";
	return $filter;
}
?>
	
</head>
<body>
<?php
	echo "<h1>Mailing list $listName</h1>";

//	echo "<button onClick='home()'>Home</button>";
	echo "<p><button onClick='mbvNewMember(0)'>New recipient</button></p>";

	echo "<div class='container'>";
	
	echo heading();
	echo "<br><br>";
	
	$rtable = $lstRecord['rtable'];
	showList($rtable);
	
function heading()
{
	$hdg = "<span class='mll0'>email</span>"
		. "<span class='mll1'>forename</span>"
		. "<span class='mll2'>surname</span>"
//		. "<span class='mll3'>status</span>"
		. "<span class='mll3'>business</span><br><br>";
	return $hdg;
}

// ----------------------------------------------
//	Show the list of mailing lists
//
// ----------------------------------------------
function showList($rtable)
{
	global $dbConnection, $colMap, $filter;

									// Pick up the fields we need to show
									// For an external file, the columns may not be
									// the same as internals
	$ky = $colMap['ky'];
	$em = $colMap['email'];
	$forename = $colMap['forename'];
	$surname = $colMap['surname'];
	$bus = $colMap['business'];
	$sql = "SELECT $ky, $em, $forename, $surname, $bus"
		. " FROM $rtable $filter LIMIT 25 ";
//	echo "$sql<br>";
	$result = mysqli_query($dbConnection, $sql)
		or die (mysqli_error($dbConnection) . ": " . $sql);

	while ($record = mysqli_fetch_array($result))
	{
		$kval = $record[$ky];
		echo "<div style='line-height:1.5'>";
		echo "<span class='mll0' id='mle$kval'>" . $record[$em] . "</span>";
		echo "<span class='mll1' id='mlf$kval'>" . $record[$forename] . "</span>";
		echo "<span class='mll2' id='mls$kval'>" . $record[$surname] . "</span>";
		echo "<span class='mll3' id='mlb$kval'>" . $record[$bus] . "</span>";
		
		echo "<span class='mll4'>";
//		echo "<button onClick='mbvSend($kval)'>Send</button>&nbsp;&nbsp;";
		echo "<button onClick='mbvEdit($kval)'>Edit</button>&nbsp;&nbsp;";
		echo "<button onClick='mbvDelete(\"$rtable\", $kval)'>Delete</button>&nbsp;&nbsp;</span>";
		echo "<br><br></div>\n";
//		echo '<br></div>';
	}
	mysqli_free_result($result);
}

// ------------------------------------------
//  The edit form follows
//
//	Note the record id is set in showManager
// ------------------------------------------
?>
	<div id='messagecreate'>
		<div style="text-align: right" onClick='closeNewMailForm()'>X&nbsp;</div>
		<form action='RcpPost.php' method='post'>
			<b>Recipient</b>
			<br><br>
			First name <input type='text' class='mld' name='forename' id='forename'>
			<br>
			Last name <input type='text' class='mld' name='surname' id='surname'>
			<br>
			Email <input type='text' class='mld' name='email' id='email'>
			<br>
			Company <input type='text' class='mld' name='business' id='business'>
			<br><br>
			<input type='hidden' name='id' id='mid'>
			<input type='hidden' name='mode' id='mmode'>
			<input type='submit' value='Post'>
<?php
		 	echo"	<input type='hidden' name='list' value='" . $_GET['lst'] . "'>"; 
		 	echo"	<input type='text' name='table' value='$rtable'>"; 
?>
		 	<br><br>
		</form>
	</div>
	<br>
	<button onClick='home()'>Home</button>

</div>  <!-- container -->
</body>
<script>
// ----------------------------------------
//	Edit a mailing list member
//
//	Populate and show the edit form 
// ----------------------------------------
function mbvEdit(id)
{
	mbvMode = 'edit';
	var el = document.getElementById('mmode');
	el.value = 'edit';
	el = document.getElementById('mid');		// The hidded form field holds the id
	el.value = id;
												// Fetch data from the list row
	var x = 'mle' + id;
	el = document.getElementById('mle' + id);
	var el2 = document.getElementById('email');	// ...  and move into the edit form
	el2.value = el.innerHTML;
	el = document.getElementById('mlf' + id);
	el2 = document.getElementById('forename');
	el2.value = el.innerHTML;
	el = document.getElementById('mls' + id);
	el2 = document.getElementById('surname');
	el2.value = el.innerHTML;
	el = document.getElementById('mlb' + id);
	el2 = document.getElementById('business');
	el2.value = el.innerHTML;

	var el = document.getElementById('messagecreate');
	el.style.visibility = 'visible';
}

function mbvDelete(rtable, id)
{
	if (!confirm('Are you sure you want to delete this entry?'))
		return;

	var href = location.href;		// Locate the table from the calling href
	var psn = href.indexOf('lst') + 4;
	var list = href.substr(psn);
	
	var str = "RcpPost.php?action=delete&table=" + rtable + "&list=" + list + "&id=" + id;
	document.location.href = str;
}

// ----------------------------------------
//	Show the edit form when "new member"
//	is clicked
// ----------------------------------------
function mbvNewMember(mode)
{
	mbvMode = 'add';
	var el = document.getElementById('mmode');
	el.value = 'add';
	el = document.getElementById('mid');
	el.value = 0;
	el = document.getElementById('forename');
	el.value = '';
	el = document.getElementById('surname');
	el.value = '';
	el = document.getElementById('email');
	el.value = '';
	el = document.getElementById('business');
	el.value = '';
	el = document.getElementById('messagecreate');
	el.style.visibility = 'visible';
}

</script>
</html>
