<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	MailEdit.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Editor for messages 
//	Container div holds instructpane and maineditpanel
//	The latter shows the html being edited
//	Also editview, a hidden panel for CKEditor
// --------------------------------------------------------------
/*
function openMessage()
function deleteMessage()
function newMessage()
function ckeditPanel()
function showInstructPanel()
*/
?>
<!DOCTYPE html>
<head>
	<title>MT Mail Messages</title>
	<meta charset="utf-8">
	<script src="../../ckeditor/ckeditor.js"></script>
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<link rel="stylesheet" type="text/css" href="../../includes/Menus.css">
<script>
// -------------------------------------
//	Clear the change flag on page load
// -------------------------------------
function doLoad()
{
	changed = false;
}

// -------------------------------------
//	Handler for 'Back to list'
// -------------------------------------
function mslist()
{
	if (changed)
	{
		if (confirm ("Leave without saving?"))
			document.location.assign("Newsletters.php");
	}
	else
		document.location.assign("Newsletters.php");
}

// -------------------------------------
//	Handler for 'Home'
// -------------------------------------
function goHome()
{
	if (changed)
	{
		if (confirm ("Leave without saving?"))
			document.location.assign('Home.php');
	}
	else
		document.location.assign('Home.php');
}

</script>
</head>

<body style='background-color: #eeeeee;' onLoad='doLoad()'>
<br>

<?php
	require_once "LogCheck.php";

	date_default_timezone_set("Europe/London");	// Today's date
	$dtSQL = date('Y-m-d G:i:s');

	$mode = '';
	$htmlText = '';
	$id = 0;
	if (array_key_exists('id', $_GET))
		$id = $_GET['id'];
	if (array_key_exists('action', $_GET))
		$mode = $_GET['action'];

//	echo "<h1>Mailer </h1>";
	echo "<h1>Mailer: Editing message</h1>";
	echo "<p><button type='button' onClick='goHome()'>Home</button>";
	echo "&nbsp;&nbsp;";
	echo "<button type='button' onClick='mslist()'>Back to List</button></p>";

	$record = array();
	switch ($mode)
	{
	case 'new':
		$record = newMessage();
//		$htmltext = newMessage();
		break;
	case 'edit':
		$record = openMessage();
		break;
	case 'delete':
		echo deleteMessage();
		return;
	}

	$htmltext = $record['htmltext'];
	$msgname = $record['name'];
	echo "<h3>Editing message $msgname</h3>";
	
	echo "<div class='container'>";
		showInstructPanel();
		showHeaders($record);
		echo "\n<div class='maineditpanel' id='maineditpanel'>";
		echo $htmltext;
		echo "</div>";
		ckeditPanel();
	echo "</div>";
	echo "<button onClick='traceHtml()'>Trace</button>";
//

// -------------------------------------
//	Open an existing message
//
//	Message id is passed as a parameter
//
//	Creates global $msgname
// -------------------------------------
function openMessage()
{
	global $dbConnection;
	
	$sql = "SELECT * FROM mailmessages WHERE id=" . $_GET['id'];
	$result = mysqli_query($dbConnection, $sql)
		or die($sql);
	$record = mysqli_fetch_array($result);
	mysqli_free_result($result);

	return $record;
}

// -------------------------------------
//	Delete a message
//
// -------------------------------------
function deleteMessage()
{
	global $dbConnection;
	
	$sql = "DELETE FROM mailmessages WHERE id=" . $_GET['id'];
	$result = mysqli_query($dbConnection, $sql)
		or die($sql);
	return "Deleted";
}

// -------------------------------------
//  Insert a new blank message into the
//	database
// -------------------------------------
function newMessage()
{
	global $dbConnection, $dtSQL, $msgname;

	$record = array();
	$record['name'] = $_GET['msgname'];
	$record['subject'] = $_GET['subject'];
	$record['sender'] =  $_GET['from'];
	$msgname = addslashes($_GET['msgname']);
	$subject = addslashes($_GET['subject']);
	$sender = addslashes($_GET['from']);
	$template = $_GET['tp'];
	
	$sql = "SELECT * FROM templates WHERE id=$template";
	$result = mysqli_query($dbConnection, $sql)
		or die ("SQL error " . mysqli_error($dbConnection));
	$tpRecord = mysqli_fetch_array($result);
	$htmltext = $tpRecord['htmlText'];
	$record['htmltext'] = $htmltext;
	
	mysqli_free_result($result);

	$sql = "INSERT INTO mailmessages (name, subject, sender, created, htmltext) "
		. "VALUES ('$msgname', '$subject', '$sender', '$dtSQL', '" 
		. addslashes($htmltext) . "')";

	mysqli_query($dbConnection, $sql)
		or die ("SQL error " . mysqli_error($dbConnection) . $sql);

	return $record;
}

// -------------------------------------
// -------------------------------------
function showHeaders($record)
{
	echo "<div class='headerpanel'><br>";
//	echo "<div class='headerpanel' style='positiotop:80px; left:200px; padding-left:5px'>";
//	echo "<form>";
	$name = $record['name'];
	$subject = $record['subject'];
	$sender = $record['sender'];
	echo "<span class='prompt1'>Message name</span>";
	echo "<span class='inputhd'><input type='text' id='mcName' size='45' value='$name'></span>";
	echo "<br>&nbsp;&nbsp;(For your reference)<br>";
	echo "<span class='prompt1'>Subject</span>";
	echo "<span class='inputhd'><input type='text' id='mcSubject' size='45' value='$subject'></span>";
	echo "<br><br>";
	echo "<span class='prompt1'>Sender address</span>";
	echo "<span class='inputhd'><input type='text' id='mcFrom' size='45' value='$sender'></span>";
	echo "<br><br>";
	echo "</div>";
	echo "<br>";
}

// -------------------------------------
//	Present a panel for ckEditor 
//
// -------------------------------------
function ckeditPanel()
{
	echo "<div class='editorpanel' id='editview'>";
		echo "<div style='text-align: right' onClick='closeEditor()'>X&nbsp;&nbsp; </div>";
	echo "<textarea name='ed' id='editTA' rows='15' cols='60'>aaa</textarea>";
	echo "<script>";
	echo "  CKEDITOR.replace( 'ed' );";
	echo "  </script>";
	echo "<button onClick='editPost()'>Done</button>";

	echo "</div>";
}

// -------------------------------------
//	The left hand, instruction, panel
//
//	Prompt and a Save button
// -------------------------------------
function showInstructPanel()
{
	global $id;

	echo "<div class='infopanel'>";
	echo "<p>Hover over the message to highlight the sections</p>";
	echo "<p>Click on a section to edit it</p>";
	
	echo "<br><br>";
	echo "<button onClick='doSave(\"message\", $id)'>Save Edits</button>";
	echo "</div>";
}
?>

</body>
</html>
