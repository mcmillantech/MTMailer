<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	MailCreate.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Create a new messages 

// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Create new message</title>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<link rel="stylesheet" type="text/css" href="../../includes/Menus.css">
</head>

<body style='background-color: #eeeeee;'>
<?php
	include "LogCheck.php";

	echo "<h1>Mailer: Create Message</h1>";

	echo "<p><button type='button' onClick='home()'>Home</button>";
	echo "&nbsp;&nbsp;";
//	echo "<button type='button' onClick='mslist()'>Back to List</button></p>";

	echo "<div id='container'>";
	showForm();
	showSelector();
		echo "<br>";
		echo "<div style='position:absolute; top:600px; left:200px;'>";
		echo "<button onClick='mcDone()'>Done</button>";
		echo "</div>";
	echo "</div>";

function showForm()
{
	global $dbConnection;

	echo "<div class='mcform' style='top:130px; left:200px; padding-left:5px'>";
	echo "<form>";
	echo "<span class='prompt1'>Message name</span>";
	echo "<span class='input1'><input type='text' id='mcName' size='45'></span>";
	echo "<br>&nbsp;&nbsp;(For your reference)<br>";
	echo "<span class='prompt1'>Subject</span>";
	echo "<span class='input1'><input type='text' id='mcSubject' size='45'></span>";
	echo "<br><br>";
	echo "<span class='prompt1'>Sender address</span>";
	echo "<span class='input1'><input type='text' id='mcFrom' size='45'></span>";
	echo "<br><br>";
	echo "</form></div>";
}

function showSelector()
{
	global $dbConnection;

	echo "<div class='selector' style='top:300px; left:200px; padding-left:5px'>";
	echo "Select template<br><br>\n";
	$sql = "SELECT * FROM templates";
	$result = mysqli_query($dbConnection, $sql);
	while ($record = mysqli_fetch_array($result))
		showRecord($record);
	echo "</div>";
}
// ----------------------------------------------
//	Show the template record
//
// ----------------------------------------------
function showRecord($record)
{
	$id = $record['id'];
	$name = $record['name'];
	echo "<span id='tpsel$id' onClick='mcPickTemplate(\"$id\")'>$name</span>";
	echo "<br>\n";
}

?>

<script>
// ----------------------------------------
//	Handler to pick template
//
//	Sets global variable template
// ----------------------------------------
function mcPickTemplate(id)
{
	if (template != 0)			// Remove existing highlight
	{
		var span = 'tpsel' + template;
		var el = document.getElementById(span);
		el.style.fontWeight = 'normal';
	}

	template = id;				// Record the template
	var span = 'tpsel' + id;
	var el = document.getElementById(span);
	el.style.fontWeight = 'bold';
	
}

// ----------------------------------------
//	Handler for done button 
//
// ----------------------------------------
function mcDone()
{
	var el = document.getElementById('mcName');		// Fetch the fields
	var nam = encodeURI(el.value);
	el = document.getElementById('mcSubject');
	var subject = encodeURI(el.value);
	el = document.getElementById('mcFrom');
	var from = encodeURI(el.value);

	if (nam == '' || subject == '' || from == '')	// Check all data is present
	{
		alert('All fields must be filled in');
		return;
	}
	if (template == 0)
	{
		alert ('You must select a template');
		return;
	}
	
	var str = "MailEdit.php?action=new&tp=" + template	// ... and pass to MailEdit
		+ "&msgname=" + nam
		+ "&subject=" + subject
		+ "&from=" + from;
//	alert (str);
	document.location.href = str;
}

</script>
</body>
</html>
