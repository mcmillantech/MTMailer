<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	ViewLog.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  View messages sent from the queue
// --------------------------------------------------------------
/*
*/
	require_once "LogCheck.php";

?>
<!DOCTYPE html>
<html>
<head>
<title>Sent messages</title>
	<meta charset="utf-8">
</head>
<body>
<?php
	echo "<h1>Sent messages</h1>";

	echo "<button onClick='home()'>Home</button>";
	$sql = "SELECT * FROM mailqueue ORDER BY inx DESC";	
	$result = mysqli_query($dbConnection, $sql);
	echo "<div style='position:absolute'>";
	while ($record = mysqli_fetch_array($result))
	{
		echo "<p>";
		$dt = $record['queuetime'];
		$dt = substr($dt, 8, 2) . '/' . substr($dt, 5, 2) . '/' . substr($dt, 0, 4)
			. ' ' . substr($dt, 11,5);

		echo $dt . ' ';
		showField('status', 130);
		showField('lastrow', 200);
		showField('totalsent', 250);
		showField('subject', 300);
		echo "</p>\n";
	}
	echo "</div>";
	mysqli_free_result($result);


function showField($column, $left)
{
	global $record;

	echo "<span style='position:absolute; left:$left" . "px; width:200px'>";
	echo $record[$column];
	echo "</span>";
}

?>
<script>
function home()
{
	document.location.assign('Home.php');
}
</script>
</body>
</html>
