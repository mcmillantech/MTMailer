<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	AjaxPreviewList.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Ajax server 
//	Generate a preview of recipient list 
// --------------------------------------------------------------
	require_once "LogCheck.php";

	$list = $_GET['lst'];				// Look up the list
	$sql = makeListSQL($list);
//echo "$sql <br>";
	$result = mysqli_query($dbConnection, $sql)
		or die("An error has occured: table $list is missing");
	while ($recip = mysqli_fetch_array($result))
		echo $recip[$emailMap] . '<br>';
		
	mysqli_free_result($result);

function makeListSQL($list)
{
	global $dbConnection, $emailMap;

	$sql = "SELECT * FROM maillists WHERE id='$list'";
	$result = mysqli_query($dbConnection, $sql)
		or die("An error has occured: table $list is missing");
	$dta = mysqli_fetch_array($result);
	mysqli_free_result($result);

	$table = $dta['rtable'];
	$emailMap = $dta['email'];
	$col = $dta['fcol'];
	$op = $dta['fop'];
	$val = $dta['fval'];
	if ($col == '')				// Build the filter
		$where = '';
	else
	{
		$where = " WHERE $col $op $val";		// I did have quotes around $val - could fail
	}
	$sql = "SELECT * FROM $table $where LIMIT 10";
	return $sql;
}
?>

