<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	BasicMail2.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Send a basic message
//	Evoked from Send and Save buttons in BasicMail
//	$_GET can contain resend or save
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Write a basic email</title>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
<script>
// Handler for Home button
function home()
{
	document.location.assign('Home.php');
}

</script>
</head>
<body >
<?php
	include "LogCheck.php";
	include "MTMail.php";

	$name = addslashes($_POST['name']);					// Fetch data from BasicMail.php
	$subject = addslashes($_POST['subject']);
	$sender = addslashes($_POST['sender']);
	$htmltext = addslashes($_POST['htmltext']);
	date_default_timezone_set("Europe/London");	// Today's date
	$dtSQL = date('Y-m-d G:i:s');
	
	$resend = false;
	if (array_key_exists('resend', $_GET))
	{
		$resend = true;
		$msg = $_GET['resend'];
	}

	$uploadDir = "Uploads/";					// Process attached file
	$attFile = basename($_FILES["bmAttFile"]["name"]);
	if (strlen($attFile) > 0)
	{
		$reply = move_uploaded_file($_FILES["bmAttFile"]["tmp_name"], $uploadDir . $attFile);
		if ($reply == false)
			die ("BasicMail2: Uploading attachment failed");
	}

												// Save the message
	if ($resend)
	{
		$sql = "UPDATE mailmessages SET "
			. "name = '$name'," 
			. "subject = '$name'," 
			. "sender = '$name'," 
			. "htmltext = '" . addslashes($htmltext)
			. "attachment = '$attFile',"
			. "' WHERE id= $msg" ;
	}
	else
	{
		$sql = "INSERT INTO mailmessages (name, subject, sender, created, htmltext, attachment) "
			. "VALUES ('$name', '$subject', '$sender', '$dtSQL', '" 
			. addslashes($htmltext) . "', '$attFile')";
	}

	mysqli_query($dbConnection, $sql)
		or die ("SQL insert error " . mysqli_error($dbConnection) . "\n$sql");
	$msgId = $dbConnection->insert_id;		// Get the id of the new message

											// Save button was clicked - we're done
	if (array_key_exists('btnSave', $_POST))
	{
		echo "Message $name saved<br><br>";
		echo "<button onClick='home()'>Return to home</button>";
		return;
	}

											// Send button was clicked
	$mailer = new MTmail($dbConnection);
	$mailer->setMessage(0, $htmltext, $attFile);
	$mailer->sender($sender);
	$mailer->subject($subject);
	$mailer->messageName($name);
	$mailer->attach($attFile);

	$which = $_POST['bmto'];
	if ($which == 'Single')					// Send to one
		$mailer->sendByAddress($_POST['bmOne']);
	else
		$mailer->sendList($_POST['rlist']);

//	echo "Message $name sent<br><br>";
	echo "<br><br><button onClick='home()'>Return to home</button>";
?>

</body>
</html>
