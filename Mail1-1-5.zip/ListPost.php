<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	ListPost.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Create a new mail list
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit mail list entry</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
</head>

<body style='background-color: #eeeeee;'>
<h1>Mailer: Create list</h1>
<?php
	require_once "LogCheck.php";
	$list = $_GET['list'];
	if ($list=='new')
	{
		doNew();
	}
	else 
		doUpdate();

// -------------------------------------
//	New record
//
// -------------------------------------
function doNew()
{
	global	$dbConnection;

	$fval = addslashes ($_POST['fval']);
	if ($fval == '')
		$fval = 0;
	$sql = "INSERT INTO maillists ("
		. "name, rtable, email, forename, surname, business, ky, fcol, fop, fval)"
		. " VALUES ("
		. val('name')
		. val('rtable')
		. val('email')
		. val('forename')
		. val('surname')
		. val('business')
		. val('ky')
		. val('fcol')
		. val('fop')
		. "$fval)";

	mysqli_query($dbConnection, $sql)
		or die("Failed to insert list " . "$sql " . mysqli_error($dbConnection));
	echo "<br>Record added<br><br>";
	echo "<button onClick='goHome()'>Return to home</button>";
}

// -------------------------------------
//	New record
//
// -------------------------------------
function doUpdate()
{
	global	$dbConnection, $list;

	$fval = addslashes ($_POST['fval']);
	$sql = "UPDATE maillists SET "
		. "name=" . val('name')
		. "rtable=" . val('rtable')
		. "email=" . val('email')
		. "forename=" . val('forename')
		. "surname=" . val('surname')
		. "business=". val('business')
		. "ky=" . val('ky')
		. "fcol=" . val('fcol')
		. "fop=" . val('fop')
		. "fval='$fval' " 
		. "WHERE name='$list'";

	mysqli_query($dbConnection, $sql)
		or die("Failed to update list " . "$sql " . mysqli_error($dbConnection));
	echo "<br>Record updated<br><br>";
	echo "<button onClick='goHome()'>Return to home</button>";
}

// -------------------------------------
//	Take a posted value and quote it
// -------------------------------------
function val($col)
{
	$val = addslashes ($_POST[$col]);
	return "'$val',";
}

?>

<script>
function goHome()
{
	document.location.href="Home.php";
}

</script>
</body>
</html>