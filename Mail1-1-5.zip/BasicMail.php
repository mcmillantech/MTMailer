<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	BasicMail.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
// Compose and send a messages
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Write a basic email</title>
	<meta charset="utf-8">
<?php
	include "LogCheck.php";

	$ckpath = getenv('CKPATH');
	if ($ckpath=='')
		$ckpath = "../ckeditor/ckeditor.js";
	echo "<script src='$ckpath'></script>";
?>
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<style>
	</style>
</head>

<body onLoad='previewList()'>
<h1>Mailer: Write Email</h1>
<button onClick='home()'>Home</button>
<?php

	echo "<div id='container'>";
	showForm();
	echo "<div id='listpreview'>";		// This holds the (hidden) preview pane
	echo "<button type='button' onClick='closePreview()'>Close</button>"; 
	echo "</div>";
	echo "<br>";
	echo "</div>";

// ---------------------------------------
//	The Form
// ---------------------------------------
function showForm()
{
	global $dbConnection;

	$action='BasicMail2.php';
	if (array_key_exists('resend', $_GET))
	{
		$content = resendContent();
		$action .= "?resend=" . $_GET['resend'];;
	}
	else
		$content = "Dear {forename}";

	echo "<div class='basicmailform'>";
	echo "<form id='bmForm' action='$action' method='post' enctype='multipart/form-data'>";

	echo "<span class='prompt1'>Sender email address</span>";
	echo "<span class='input1'><input type='text' id='mcFrom' name='sender' size='45'></span>";
	echo "<br><br>";

	echo "<span class='prompt1'>Message name</span>";
	echo "<span class='input1'><input type='text' id='mcName' name='name' size='45' value='Basic mail'></span>";
	echo "<br>&nbsp;&nbsp;(For your reference)<br>";

	echo "\n<span class='prompt1'>Recipients</span>";			// Hidden recipient name
	echo "<span class='input1' id=bmtoone style='visibility:hidden'>";
	echo "<input type='text' id='bmToOne' name='bmOne' size='40'>";
	echo "</span>";
	echo "<span class='input1' id=bmtolist name='bmList'>";
	showRecipientList();
	echo "&nbsp;&nbsp;";
	echo "<button type='button' onClick='previewList()'>Preview</button>";
	echo "</span>";
					// Radio buttons for list or single
	echo "\n<span style='position: absolute; left:500px'>";
	echo "<input type='radio' name='bmto' value='List'  checked onChange='bmRadio(1)'>Send to a list ";
	echo "<input type='radio' name='bmto' value='Single' onChange='bmRadio(2)'> Send to one";
	echo "</span>";
	echo "<br><br>";

	echo "<span class='prompt1'>Subject</span>";
	echo "<span class='input1'><input type='text' id='subject' name='subject' size='45'></span>";
	echo "<br><br>";

	echo "<textarea name='htmltext' id='editTA' rows='25' cols='60'>$content</textarea>";
	echo "<script>";
	echo "  CKEDITOR.replace( 'htmltext' );";
	echo "  </script>";

	echo "<br><br>";
	echo "<button type='button' onClick='bmSend()' name='btnSend'>Send</button>";
	echo "&nbsp;&nbsp;&nbsp;";
	echo "<button onClick='bmSend()' name='btnSave'>Save</button>";
	echo "&nbsp;&nbsp;&nbsp;";
	echo "<input type='button' onClick='bmAttach()' value='Attach...'>";
	echo "&nbsp;&nbsp;";
	echo "<input type='file' name='bmAttFile' id='bmAttFile' style='visibility:hidden'>";
	echo "</form></div>";
}

// -------------------------------------------
//	Build and show recipient lists drop down 
//
// -------------------------------------------
function showRecipientList()
{
	global $dbConnection;

	echo "<select id='bmToList' name='rlist' style='width:100px' onChange='previewList()'>";
	$sql = "SELECT * FROM maillists";
	$result = mysqli_query($dbConnection, $sql)
		or die ("Error : $sql");
	while ($record = mysqli_fetch_array($result))
	{
		$name = $record['name'];
		$list = $record['id'];
		echo "<option value='$list'>$name</option>";
	}
	echo "</select>";
}

function resendContent()
{
	global $dbConnection;
	
	$msg = $_GET['resend'];
	$sql = "SELECT htmltext FROM mailmessages WHERE id=$msg";
	$result = mysqli_query($dbConnection, $sql)
		or die (mysqli_error($dbConnection));
	$record = mysqli_fetch_array($result);
	$content = $record['htmltext'];
	mysqli_free_result($result);

	return $content;
}
?>
<script>
// ---------------------------------------
//	Handler for radio buttons
//
// ---------------------------------------
function bmRadio(which)
{
	switch (which)
	{
	case 1:
		var el = document.getElementById('bmtoone');
		el.style.visibility = 'hidden';
		el = document.getElementById('bmtolist');
		el.style.visibility = 'visible';
		break;
	case 2:
		var el = document.getElementById('bmtolist');
		el.style.visibility = 'hidden';
		el = document.getElementById('bmtoone');
		el.style.visibility = 'visible';
		break;
	}
}

function bmSend()
{
	var el = document.getElementById('mcFrom');
	if (el.value.length < 2)
	{
		alert ("You must include a sender address");
		return;
	}
	el = document.getElementById('subject');
	if (el.value.length < 2)
	{
		if (!confirm("Do you want to send without a subject?"))
			return;
	}
	
	document.getElementById("bmForm").submit();
}

function home()
{
	document.location.assign('Home.php');
}

function bmSave()
{
	alert('Save');
}

function bmAttach()
{
	var el = document.getElementById('bmAttFile');
	el.style.visibility = 'visible';
}

</script>
</body>
</html>
