<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	MTMail.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//	Class to implement mail via Pear mail
//
//	Constructed from a message
// --------------------------------------------------------------
/*
function __construct($dbConnection)
public function setMessage($id, $html, $attFile)
public function sender($sender)
public function messageName($name)
public function subject($subject)
public function attach($attFile)
public function setPearMail($pearMail)
public function setMap($recip)
public function setList($queue)
public function setQueueData($html, $subject)

public function lst()
public function text()
public function headers()

public function sendList($listId)
public function sendOne($rtable, $rcid)
public function sendByAddress($email)
public function sendQueued($record)

private function generate()
private function sendOn($email)
private function merge($htxt, $recipient)
private function makeLines($text)
private function plainText($htxt)
private function mergeField($htxt, $pt1, $pt2, $recipient)
private function makeHeaders($dbConnection)
private function writeSentMessage()
private function lookUpMessage()
*/

if ($_SERVER['SERVER_NAME'] != 'localhost')
{
	require_once "PEAR.php";
	require_once "Mail.php";
	require_once "Mail/mime.php";
}


class MTMail
{
	private	$id;
	private $list;
	private	$htmlLines;
	private	$plainLines;
	private	$subject;
	private	$sender;
	private $messageName;
	private	$rawHtml;
	private	$attFile;
	private	$text;			// Final body text to be sent
	private	$headers;
	private	$pearMail;
	private	$boundary;
	private	$mergedHtml;
	private	$mergedPlain;

	// ----------------------------------------------
	
	function __construct($dbConnection)
	{
		global	$dbConnection;

		$list = array();
		$this->boundary = uniqid('np');		//create a boundary for the email - is this needed?
		$this->makeHeaders($dbConnection);
	}

	public function setMessage($id, $html, $attFile)
	{
		global	$dbConnection;

		$this->id = $id;
		$this->rawHtml = $html;
		$this->attFile = $attFile;
//		$this->attFile = getcwd() . '/' . $attFile;
	}

	public function sender($sender)
	{
		$this->sender = $sender;
	}

	public function messageName($name)
	{
		$this->messageName = $name;
	}

	public function subject($subject)
	{
		$this->subject = $subject;
		$headers['Subject'] = $subject;
	}

// --------------------------------------------
//	Set an attachment
//
//	Constructor also sets attach
// --------------------------------------------
	public function attach($attFile)
	{
		$uploadDir = "Uploads/";
		$this->attFile = $uploadDir . $attFile;
	}

	public function setPearMail($pearMail)
	{
		$this->pearMail = $pearMail;
	}


// --------------------------------------------
//	Map the sending fields (e.g. email)
// --------------------------------------------
	public function setMap($recip)
	{
		$em = $this->list['email'];
		$fname = $this->list['forename'];
		$sname = $this->list['surname'];
		$co  = $this->list['business'];
		$recip['email'] = $recip[$em];
		$recip['business'] = $recip[$co];
		$recip['forename'] = $recip[$fname];
		$recip['surname'] = $recip[$sname];
		return $recip;
	}
	// --------------------------------------------------------
	//  Fetch data to the map of user's column names to ours
	//
	// --------------------------------------------------------
	public function setList($queue)
	{
		global	$dbConnection;

		$sqlm = "SELECT * FROM maillists WHERE id='" . $queue['listid'] . "'";
		$resultm = mysqli_query($dbConnection, $sqlm)
			or die("Mapping error " . mysqli_error($dbConnection) . $sqlm);
		$this->list = mysqli_fetch_array($resultm);
		mysqli_free_result($resultm);
	}

	// ----------------------------------------------
	//	From the queue, set the body and subject
	//
	// ----------------------------------------------
	public function setQueueData($html, $subject)
	{
		$this->rawHtml = $html;

		$this->subject = $subject;
		$this->headers['Subject'] = $subject;
	}

//	----------  Return attributes
	public function lst()
	{
		return $this->list;
	}
	public function text()
	{
		return $this->text;
	}
	public function headers()
	{
		return $this->headers;
	}
///	

// --------------------------------------------
//	Send mail to a list
//
//	Insert the details into the mail queus
// --------------------------------------------
	public function sendList($listId)
	{
		global	$dbConnection;

		$t=time();
		$dt = date('Y-m-d G:i:s');

		$sql = "INSERT INTO mailqueue "
			. "(messageid, listid, queuetime, lastrow, subject, sender, html, attachment, status) "
			. "VALUES ("
			. "$this->id,"
			. "'$listId',"
			. "'$dt',"
			. "0,"
			. "'" . addslashes($this->subject) . "',"
			. "'" . addslashes($this->sender) . "',"
			. "'" . addslashes($this->rawHtml) . "',"
			. "'$this->attFile',"
			. "'new')";

		mysqli_query($dbConnection, $sql)
			or die("Send list error " . mysqli_error($dbConnection) . " $sql");

		$this->lookUpMessage();
		$this->writeSentMessage();

		echo "Thank you. Your email has been scheduled for sending";
	}

// -------------------------------------------------
//	Send mail to named recipient by id
//
//	Paramter	recipient id
//	This is not used at present - could be called
//	From GenerateNews to one addressee
// -------------------------------------------------
	public function sendOne($rtable, $rcid)
	{
		global $dbConnection;
	
		$rtable = $_POST['table'];
		$sql = "SELECT * FROM $rtable WHERE id=$rcid";
		$result = mysqli_query($dbConnection, $sql)
			or die("List error " . mysqli_error($dbConnection) . $sql);
		$record = mysqli_fetch_array($result);

		$this->mergedHtml = $this->merge($this->htmlLines, $record);
		$this->mergedPlain = $this->merge($this->plainLines, $record);
		$this->generate();
		$this->sendOn($record['email']);
	}

// --------------------------------------------
//	Send mail to named recipient by email addr
//
//	Paramter	recipient's email
// --------------------------------------------
	public function sendByAddress($email)
	{
		$this->mergedHtml = $this->htmlLines;
		$this->mergedPlain = $this->htmlLines;
		$this->generate();
		$this->sendOn($email);
	}

// -----------------------------------------------
//	Send one message from the queue
//	This is the call point from the CRON job
//
//	Parameter	Record for the recipient
//				i.e. his email and merge data
// -----------------------------------------------
	public function sendQueued($record)
	{
		$to = $record['email'];
		if ($to == '')
			return;
		$cleanedHtml = $this->stripMTEditHandlers($this->rawHtml);
		$this->mergedHtml = $this->merge($cleanedHtml, $record);
		$this->mergedPlain = $this->plainText($this->mergedHtml);
//		$this->mergedHtml = $this->makeLines($this->mergedHtml);
//		$this->mergedPlain = $this->makeLines($this->mergedPlain);

		$this->generate($record);
		$this->headers['To'] = $to;
		$this->headers['From'] = $this->sender;

		if ($_SERVER['SERVER_NAME'] != 'localhost')		// Release mode
		{
			$crlf = "\n";
			$mime = new Mail_mime($crlf);
			$mime->setHTMLBody($this->mergedHtml);
			$mime->setTXTBody($this->mergedPlain);
			if ($this->attFile != '')
			{
				$rp = $mime->addAttachment($this->attFile);
//				echo " Att reply $rp, $this->attFile\n";
			}
			$body = $mime->get();
			$headers = $mime->headers($this->headers);
			$mail =& Mail::factory('sendmail', $this->params);
			$result = $mail->send($to, $headers, $body);
			var_dump($result);
		}
		else					// Development mode - running on local PC
		{
			echo "\n<br>$to<br>";
			echo $this->mergedHtml;
			echo "Sender " . $this->headers['From'];
			echo "----------------<br>\n";
		}
	}

// --------------------------------------------
//	Generate the message 
//
//	Merge data into both plain and html lines
//	Set up the encoding etc
// --------------------------------------------
	private function generate()
	{
		global	$dbConnection;
		
		$message = "This is a MIME encoded message.";
		$message .= "\r\n\r\n--" . $this->boundary . "\r\n";
		$message .= "Content-type: text/plain;charset=utf-8\r\n\r\n";
		$message .= $this->mergedPlain;

		$message .= "\r\n\r\n--" . $this->boundary . "\r\n";
		$message .= "Content-type: text/html;charset=utf-8\r\n\r\n";
	
		$message .= $this->mergedHtml . "\r\n\r\n--" . $this->boundary . "--";
		$this->text = $message;
	}

// --------------------------------------------
	private function sendOn($email)
	{
		$headers['To'] = $email;
		$headers['Subject'] = $this->subject;

		$to = $email;

		$params['sendmail_path'] = '/usr/lib/sendmail';
		if ($_SERVER['SERVER_NAME'] != 'localhost')
		{
			$mail =& Mail::factory('sendmail', $params);
			$result = $mail->send($to, $this->headers, $this->text);
		var_dump($result);
		}
		else echo "Send by $this->text";
	}

// --------------------------------------------
//	Process the merge
//
//	Returns the merged HTML
// --------------------------------------------
	private function merge($htxt, $recipient)
	{
		$ptr = strpos($htxt, '{', 0);				// Start of 1st placeholder
		if (!$ptr)									// There aren't any - use the raw text
			return $htxt;

		$result = substr($htxt, 0, $ptr);			// Text before 1st ph

		$pt2 = strpos($htxt, '}', $ptr) + 1;		// End of ph + 1 psn
		$result .= $this->mergeField($htxt, $ptr, $pt2, $recipient);
	
		while ($ptr != 0)
		{
			$ptr = strpos($htxt, '{', $pt2);		// Start of next section
			if (!$ptr)								// No more tags
			{
				$result .= substr($htxt, $pt2);
				break;
			}
			$len = $ptr - $pt2;
			$result .= substr($htxt, $pt2, $len);
			$pt2 = strpos($htxt, '}', $ptr) + 1;	// End of ph + 1 psn
			$result .= $this->mergeField($htxt, $ptr, $pt2, $recipient);
		}
		return $result;
	}

// -----------------------------------------------
// 	Build lines < 70 characters long
//
//	Returns string with long lines broken up
// -----------------------------------------------
	private function makeLines($text)
	{
		$lines = explode("\n", $text);			// Start by breaking message into lines

		$splitText = '';						// This is the output string
		foreach ($lines as $str)				// Now process each line
		{
			if (strlen($str) > 70)				// Process lines longer than 70 characters
			{
				$tr = 0;
				while (strlen($str) > 70)		// Loop through long lines
				{
					$tstStr = substr($str, 0, 70);
					$psn = strrpos($tstStr, ' ');	// Break each line on a space
					if ($psn == false)
						$psn = strrpos(substr($str, 0, 70), '>');	// ... or tag
					if ($psn == false)
						$psn = strlen($str);		// Give up and hope
													// Append this text and a line break
					$splitText .= substr($str, 0, $psn) . "\r\n"; 
					$str = substr($str, $psn);
					if ($tr++ > 10)
						die ("Looping making lines: $str ");
				}
				$splitText .= "$str\r\n";					// Finish the lines as RFC...
			}
			else
				$splitText .= "$str\r\n";					// OK, this line was < 70 characters
		}
		return $splitText;
	}

// --------------------------------------------
//	Generate plain text
//
// --------------------------------------------
	private function plainText($htxt)
	{
		$ptr = strpos($htxt, '<', 0);			// Start of 1st tag
		$out = substr($htxt, 0, $ptr);			// Text before 1st tag
		$pt2 = strpos($htxt, '>', $ptr) + 1;	// End of tag + 1 psn
		$len = strlen($htxt);

		do
		{
			if ($pt2 > $len)
				break;
			$ptr = strpos($htxt, '<', $pt2);		// Start of next section
			$thisLen = $ptr - $pt2;
			$out .= substr($htxt, $pt2, $thisLen);
			$pt2 = strpos($htxt, '>', $ptr) + 1;	// End of tag + 1 psn
		} while ($ptr != 0);
		return $out;
	}

// --------------------------------------------
//	Set one merged field
//
//	Parameters 
//		the raw text string
//		pt1 and p2t point to the merge tag,
//			i.e. between braces
//		the record from the recipient table
//
//	Extract the tag name.
//	If the tag is invalid, ignore
//	Else, return the field from the table
// --------------------------------------------
	private function mergeField($htxt, $pt1, $pt2, $recipient)
	{
		$len = $pt2 - $pt1 - 2;
		$key = substr($htxt, $pt1+1, $len);

		if (!array_key_exists($key, $recipient))
			return '';
		return $recipient[$key];
	}

// --------------------------------------------
//	Build the mail headers
//
// --------------------------------------------
	private function makeHeaders($dbConnection)
	{
		$headers['From'] = $this->sender;
		$headers['Subject'] = $this->subject;
		$headers['MIME-Version'] = "1.0";
		$headers['Content-Type'] = "multipart/alternative;boundary=" 
			. $this->boundary;

		$this->headers = $headers;
	}

// ------------------------------------------
//  Strip out the handlers used to edit the
//	sections (onClick, onMouse...)
// ------------------------------------------
	private function stripMTEditHandlers($html)
	{
								// Locate each edit block: between $block0 and $blockn
		$psn = 0;
		$block0 = strpos($html, 'editblock', $psn);
		while ($block0 != false)
		{
			$blockn = strpos($html, '>', $block0);
			$len = $blockn-$block0+1;
			$psn = $blockn;
		
			$editBlock = substr($html, $block0, $len);
			$editBlock = $this->removeHandler($editBlock, 'onclick', 12);
			$editBlock = $this->removeHandler($editBlock, 'onmouse', 20);
			$editBlock = $this->removeHandler($editBlock, 'onmouse', 20);
			$html = substr_replace($html, $editBlock, $block0, $len);
	
			$block0 = strpos($html, 'editblock', $psn);
		}
		return $html;
	}

// --------------------------------------------------------
//	Remove one handler
//	Parameters
//		The contents of the td tag from 'editBlock'
//		The event
//		Number of chars after event before checking for "
//	Returns
//		The input, with the handler removed
// --------------------------------------------------------
	private function removeHandler($block, $event, $chars)
	{
								// Locate handler: from $h0 to $hn	
		$h0 = strpos($block, $event, 0);
		if (!$h0)
			return $block;
	
		$hn = strpos($block, '"', $h0+$chars);
		$len = $hn - $h0 + 1;					// start and length of handler
		
		$htm2 = substr_replace($block, '', $h0, $len);	// Remove it
		return $htm2;
	
	}


// -------------------------------------------------
// Write to messages table
// -------------------------------------------------
	private function writeSentMessage()
	{
		global	$dbConnection;

		$t=time();
		$dt = date('Y-m-d G:i:s');

		$sql = "INSERT INTO sentmessages "
			. "(name, sender, subject, lastsend, htmltext) VALUES ("
			. "'$this->messageName',"
			. "'$this->sender',"
			. "'" . addslashes($this->subject) . "',"
			. "'$dt',"
			. "'" . addslashes($this->htmlLines) . "')";
		mysqli_query($dbConnection, $sql)
			or die("Send list error " . mysqli_error($dbConnection) . " $sql");

	}

// -------------------------------------------------
// Look up message name
// -------------------------------------------------
	private function lookUpMessage()
	{
		global	$dbConnection;

		$sql = "SELECT name FROM mailmessages WHERE id=$this->id";
		$result = mysqli_query($dbConnection, $sql)
			or die("Look up message error " . mysqli_error($dbConnection) . " $sql");
		$record = mysqli_fetch_array($result);
		$this->messageName = $record['name'];
		mysqli_free_result($result);
	}
} 
?>
