<?php
	session_start();
									// See if a user is logged on
	if (!array_key_exists('mailuser', $_SESSION))
	{
		header('Location: Logon.php');
//		exit;
	}

									// Now there should be a session - process timeout
	$tm = time();
	$lastTime = 0;
	if (array_key_exists('lastAccess', $_SESSION))
		$lastTime = $_SESSION['lastAccess'];
	if (($tm - $lastTime) > 3600)
	{
		session_unset();
		session_destroy();
		header('Location: Logon.php');
//		exit;
	}

	$_SESSION['lastAccess'] = $tm;
									// Yes. As this is a common file, its' a good place to open 
									// the database connection. Details are in the config file
									// which is read by AjaxLogon
	$config = $_SESSION['config'];
	$dbConnection = mysqli_connect ('localhost', $config['dbuser'], $config['dbpw'])
		or die("Could not connect : " . mysqli_error($dbConnection));
	
	mysqli_select_db($dbConnection, $config['dbname']) 
		or die("Could not select database : " . mysqli_error($dbConnection));

?>
