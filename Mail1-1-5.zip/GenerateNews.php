<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	Generate.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//	Generate and send newsletters
//	Called from mailSendm
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Email Messages</title>
	<meta charset="utf-8">
	<script src="MailEdit.js"></script>
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
	<link rel="stylesheet" type="text/css" href="../../includes/Menus.css">
</head>

<body>
<h1>Mailer: Messages</h1>
<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	GenerateNews.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//	Called from SendNews.php
//
//	Routes from the Send buttons to an MTMail object
// -------------------------------------------------------------
	include "LogCheck.php";
	include "MTMail.php";

	$ltrid = $_POST['msgid'];
//	$rtable  = $_POST['table'];
	$subject = $_POST['subject'];
	$sender = $_POST['from'];
	$lstid = $_POST['rcid'];
	date_default_timezone_set("Europe/London");	// Today's date
	$dtSQL = date('Y-m-d G:i:s');

	$sql = "SELECT name, htmltext FROM mailmessages WHERE id=$ltrid";
	$result = mysqli_query($dbConnection, $sql)
		or die ("SQL error " . mysqli_error($dbConnection) . $sql);
	$stdMail = mysqli_fetch_array($result);
	$htmltext = $stdMail['htmltext'];
	$name = $stdMail['name'];
	mysqli_free_result($result);

	$mailer = new MTmail($dbConnection);
	$mailer->setMessage($ltrid, $htmltext, '');
	$mailer->sender($sender);
	$mailer->subject($subject);
						// Mode is a hidden field in SendNews - this could allow sending to one address
	$mode = $_POST['mode'];
	if ($mode == 'one')
		$mailer->sendOne($rtable, $lstid);
	else
		$mailer->sendList($lstid);

	echo "<br><button onClick='goHome()'>Home</button>";

?>
<script>
function goHome()
{
	document.location.href="Home.php";
}

</script>
</body>
</html>