<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	AjaxMail.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Ajax server for mail
//		mode	mail - called from MailSend
// --------------------------------------------------------------
/*
*/
//	$db_name = 'web121-mtdbase';
	$db_name = 'contacts';
//	$dbConnection = mysqli_connect ('localhost', $db_name, 'fender7')		// server
	$dbConnection = mysqli_connect ('localhost', 'root', 'sql')			// local test
		or die("Could not connect : " . mysqli_error($dbConnection));
	mysqli_select_db($dbConnection, $db_name) 
		or die("Could not select database : " . mysqli_error($dbConnection));

	$mode = $_GET['mode'];
	if ($mode == 'mail')
		getMailData();

// -----------------------------------------
//	Fetch data for mail sending
//
// -----------------------------------------
function getMailData()
{
	global $dbConnection;
	$id = $_GET['id'];

	$sql = "SELECT * FROM messages WHERE id=$id";	
	mysqli_query($dbConnection, $sql)
		or die("An error occured saving the message: $sql");
	$result = mysqli_query($dbConnection, $sql);
	$record = mysqli_fetch_array($result);
	$subject = $record['subject'];
	$sender = $record['sender'];
	echo "$subject|$sender";
}
?>
