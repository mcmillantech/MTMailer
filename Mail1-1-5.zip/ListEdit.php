<?php
// -------------------------------------------------------------
//  Project	Emailer
//	File	ListEdit.php
//
//	Author	John McMillan
//  McMillan Technology Ltd
//
//  Create or edit new mail list
// --------------------------------------------------------------
/*
*/
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit mail list entry</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="MailEdit.css">
</head>

<body style='background-color: #eeeeee;'>
<h1>Mailer: create / edit list</h1>
<?php
	include "LogCheck.php";

	$mode = $_GET['mode'];
	$list = $_GET['list'];
	if ($mode=='new')
	{
		$record = array
		(
			'name' => '',
			'rtable' => '',
			'forename' => 'forename',
			'surname' => 'surname',
			'email' => 'email',
			'ky' => 'id',
			'business' => '',
			'fcol' => '',
			'fop' => '',
			'fval' => ''
		);
	}
	else if ($mode=='edit')
	{
		$sql="SELECT * FROM maillists WHERE name='" . $_GET['list'] . "'";
		$result = mysqli_query($dbConnection, $sql)
			or die("Failed to fetch list " . "$sql " . mysqli_error($dbConnection));
		$record = mysqli_fetch_array($result);
		mysqli_free_result($result);
	}

	echo "<div id='container'>";
	showForm($record, $list);
	echo "</div>";
	echo "<button onClick='home()'>Home</button>";

// -------------------------------------
//	Show the form
//
//	Parameters
//			record - from lists table
//					or defaults for new
//			list table or 'new'
// -------------------------------------
function showForm($record, $list)
{
	$style = "top:130px; left:200px; padding:10px;";
	echo "<div class='mcform' style='$style'>";
	
	echo "\n<form onsubmit='return validate()' action='ListPost.php?list=$list' method='post'>";

	echo "<span class='prompt1'>List name</span>";
	showLine($record, 'name', 45);
	echo "<span class='prompt1'>List table</span>";
	showLine($record, 'rtable', 45);

	echo "<br><span class='prompt1'>Column maps</span><br>";
	echo "<span class='prompt1'>&nbsp;&nbsp;Email</span>";
	showLine($record, 'email', 45);
	echo "<span class='prompt1'>&nbsp;&nbsp;Forename</span>";
	showLine($record, 'forename', 45);
	echo "<span class='prompt1'>&nbsp;&nbsp;Surname</span>";
	showLine($record, 'surname', 45);
	echo "<span class='prompt1'>&nbsp;&nbsp;Business</span>";
	showLine($record, 'business', 45);
	echo "<span class='prompt1'>&nbsp;&nbsp;Key field</span>";
	showLine($record, 'ky', 45);

	echo "<br><span class='prompt1'>Filter</span><br>";
	echo "<span class='prompt1'>&nbsp;&nbsp;Columns</span>";
	showLine($record, 'fcol', 45);
	echo "<span class='prompt1'>&nbsp;&nbsp;Operator</span>";
	showLine($record, 'fop', 5);
	echo "<span class='prompt1'>&nbsp;&nbsp;Value</span><br>";
	echo "<span class='prompt1'>&nbsp;&nbsp;&nbsp;(Enclose in single quotes)</span>";
	showLine($record, 'fval', 45);
	
	echo "<br><br>";
	echo "<input type='submit' value='post'>";
	echo "<span class='input1'><button type='button' onClick='genTable()'>Generate table name</button></span>";

	echo "</div>";
}

// -------------------------------------
//	Show one entry field
//
//	Parameters
//			Record holding data
//			This column
//			Field size
// -------------------------------------
function showLine($record, $column, $size)
{
	$val = $record[$column];
	echo "\n<span class='input1'><input type='text' id='$column' name=$column size='$size' value='$val'></span>";
	echo "<br>";
}

?>

<script>

// ------------------------------------------------
//	Validate form on submit
//
//	May not be needed after change to new list
// ------------------------------------------------
function validate()
{
	var el = document.getElementById('rtable');
	if (el.value == ''){
		alert ('List table must be present');
		return false;
	}
	return true;
}

// ------------------------------------------------
//	JS generate new table
//
//	Use AJAX to create the table and fetch its name
// -------------------------------------------------
function genTable()
{
	var hAjax;
	hAjax = new XMLHttpRequest();
	
	hAjax.onreadystatechange=function()	
	{
		if (hAjax.readyState==4 && hAjax.status==200)
		{
			var el = document.getElementById('rtable');
		    var httxt = hAjax.responseText;
		    el.value = httxt;
							//	Need to disable the generate button
	    }
    }
	hAjax.open("GET","AjaxNewFile.php",true);
	hAjax.send();
}

function home()
{
	document.location.assign('Home.php');
}

</script>
</body>
</html>
